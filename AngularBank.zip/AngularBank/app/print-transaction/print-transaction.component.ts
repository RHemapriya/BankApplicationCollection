import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-print-transaction',
  templateUrl: './print-transaction.component.html',
  styleUrls: ['./print-transaction.component.css']
})
export class PrintTransactionComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
