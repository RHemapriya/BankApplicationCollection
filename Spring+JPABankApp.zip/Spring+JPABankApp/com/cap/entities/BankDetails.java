package com.cap.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Account1")

public class BankDetails {
	@Id
	@Column(name="accNo",length=20)
	@GeneratedValue
	private int accNo;
	@Column(name="accName",length=20)
	private String accName;
	@Column(name="accMobileNo",length=20)
	private long accMobileNo;
	@Column(name="accType",length=20)
	private String accType;
	@Column(name="accBranch",length=20)
	private String accBranch;
	@Column(name="accBalance",length=20)
	private int accBalance;
	
	public int getAccNo() {
		return accNo;
	}
	public void setAccNo(int accNo) {
		this.accNo = accNo;
	}
	public String getAccName() {
		return accName;
	}
	public void setAccName(String accName) {
		this.accName = accName;
	}
	public long getAccMobileNo() {
		return accMobileNo;
	}
	public void setAccMobileNo(long accMobileNo) {
		this.accMobileNo = accMobileNo;
	}
	public String getAccType() {
		return accType;
	}
	public void setAccType(String accType) {
		this.accType = accType;
	}
	public String getAccBranch() {
		return accBranch;
	}
	public void setAccBranch(String accBranch) {
		this.accBranch = accBranch;
	}
	public int getAccBalance() {
		return accBalance;
		
	}
	public void setAccBalance(int accBalance) {
		this.accBalance = accBalance;
	}

	
	@Override
	public String toString() {
		return "BankDetails [accNo=" + accNo + ", accName=" + accName + ", accMobileNo=" + accMobileNo + ", accType="
				+ accType + ", accBranch=" + accBranch + ", accBalance=" + accBalance + "]";
	}
	
	
	
}
