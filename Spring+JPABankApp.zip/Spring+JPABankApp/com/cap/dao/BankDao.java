package com.cap.dao;

import java.util.List;

import com.cap.entities.BankDetails;
import com.cap.entities.BankTransaction;

public interface BankDao {
	void createBankAccount(BankDetails bankdetail);
	
	int showTheBalance(int accNo);

	int depositAmount(int accNo, int deposit);
	
	int withdrawAmount(int accNo,int withdraw);
	
	int fundTransfer(int accNo,int accNo1,int amount);
	
	public abstract List<BankTransaction> printTransaction();
	


}
