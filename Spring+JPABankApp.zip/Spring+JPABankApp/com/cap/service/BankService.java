package com.cap.service;

import java.util.List;

import com.cap.entities.BankDetails;
import com.cap.entities.BankTransaction;

public interface BankService {
	void createBankAccount(BankDetails bankdetail);

	int showTheBalance(int accNo);

	int depositAmount(int accNo, int deposit);

	int withdrawAmount(int accNo, int withdraw);

	int fundTransfer(int accNo, int accNo1, int amount);

	public abstract List<BankTransaction> printTransaction();
	
	public boolean checkNameIsOk(String custName); //validate the customer name
	
	public boolean checkMobileNum(Long custMobile); //validate the mobile number

}
