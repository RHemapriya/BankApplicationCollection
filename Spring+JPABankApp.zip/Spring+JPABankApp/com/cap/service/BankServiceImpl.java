package com.cap.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cap.dao.BankDao;
import com.cap.dao.BankDaoImpl;
import com.cap.entities.BankDetails;
import com.cap.entities.BankTransaction;
@Service("bankService")
public class BankServiceImpl implements BankService {
	private BankDao dao;
	@Autowired	
	public void setDao(BankDao dao) {
		this.dao = dao;
	}

	@Override // create the bank account using createBankAccount method
	public void createBankAccount(BankDetails bankdetail) {
		dao.createBankAccount(bankdetail);

	}

	@Override // showing the balance using showTheBalance method
	public int showTheBalance(int accNo) {
		int accBalance = dao.showTheBalance(accNo);
		return accBalance;
	}

	// deposit the amount using depositAmount method
	public int depositAmount(int accNo, int deposit) {
		return dao.depositAmount(accNo, deposit);
	}

	@Override // withdraw the amount using the withdrawAmount method
	public int withdrawAmount(int accNo, int withdraw) {
		return dao.withdrawAmount(accNo, withdraw);
	}

	@Override // transfer the fund using fundTransfer method
	public int fundTransfer(int accNo, int accNo1, int amount) {
		return dao.fundTransfer(accNo, accNo1, amount);
	
	}

	@Override // using list for print the transaction
	public List<BankTransaction> printTransaction() {
		 List<BankTransaction> list=dao.printTransaction();
	     return list;
	}

	@Override // validate the name
	public boolean checkNameIsOk(String custName) {
		if (custName.matches("[A-Z][a-zA-Z]*")) {
			return true;
		} else {
			return false;
		}
	}

	@Override // validate the mobile number
	public boolean checkMobileNum(Long custMobile) {
		String mno = Long.toString(custMobile);
		if (mno.matches("[7-9][0-9]{9}")) {
			return true;
		} else {
			return false;
		}
	}

}
