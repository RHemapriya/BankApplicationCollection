package com.cap.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.cap.bean.BankDetails;
import com.cap.bean.BankTransaction;
import com.cap.excep.AccountNotFoundException;

public class BankDaoImpl implements BankDao {
	BankDetails bd=new BankDetails();
	BankTransaction tran=new BankTransaction();
	Connection conn = DBConnect.getConnection();
	@Override
	public int createBankAccount(BankDetails bankdetail) {
		// Class.forName(driver);
		
		PreparedStatement stmt;
		int accNo=0;
		try {
			stmt = conn.prepareStatement("insert into BankInformation values(accnoseqce.nextval,?,?,?,?,?)");

			stmt.setString(1, bankdetail.getAccName());
			stmt.setLong(2, bankdetail.getAccMobileNo());
			stmt.setString(3, bankdetail.getAccType());
			stmt.setString(4, bankdetail.getAccBranch());
			stmt.setInt(5, bankdetail.getAccBalance());
			int result = stmt.executeUpdate();
			if (result > 0)
			{
				PreparedStatement psmt = conn.prepareStatement("select accnoseqce.currval from dual");
				ResultSet rs = psmt.executeQuery();
				rs.next();
				accNo= rs.getInt(result);
				bankdetail.setAccNo(accNo);
			}
		}
		catch (Exception e) {
			System.out.println(e);
		}
		return accNo;
	}

	@Override
	public int showTheBalance(int accNo) {
		int balance=0;
		 try {
           PreparedStatement stmt1=conn.prepareStatement("select balance from BankInformation where accountno=?");
           stmt1.setInt(1,accNo);
		   ResultSet result1 =stmt1.executeQuery();
		   result1.next();
		   balance=result1.getInt(1);
		} 
		 catch (SQLException e) {
			e.printStackTrace();
		}
		return balance;
	}

	@Override
	public int depositAmount(int accNo, int deposit) {
		int balance=0;
		try {
			PreparedStatement stmt2=conn.prepareStatement("select balance from BankInformation where accountno=?");
			stmt2.setInt(1,accNo);
			ResultSet result2=stmt2.executeQuery();
			result2.next();
			balance=result2.getInt(1);
			PreparedStatement stmt3=conn.prepareStatement("update BankInformation set balance=? where accountno=? ");
			deposit=balance+deposit;
			stmt3.setInt(1, deposit);
			stmt3.setInt(2, accNo);
			int result3=stmt3.executeUpdate();
			if(result3>0)
			{
				PreparedStatement stmt33=conn.prepareStatement("insert into BankTransaction values(tranidseq.nextval,?,?,?,?,?)");
				stmt33.setInt(1,accNo);
				stmt33.setInt(2,accNo);
		    	stmt33.setInt(3,balance);
				stmt33.setInt(4,deposit);
		    	stmt33.setString(5,"Deposit");
		    	int result33 = stmt33.executeUpdate();
			}
			
		}
		catch (SQLException e) {
			e.printStackTrace();
		}

		return deposit;
	}

	@Override
	public int withdrawAmount(int accNo, int withdraw) {
		int balance=0;
		try {
			PreparedStatement stmt4=conn.prepareStatement("select balance from BankInformation where accountno=?");
			stmt4.setInt(1,accNo);
			ResultSet result4=stmt4.executeQuery();
			result4.next();
			balance=result4.getInt(1);
			PreparedStatement stmt5=conn.prepareStatement("update BankInformation set balance=? where accountno=?");
			withdraw=balance-withdraw;
			stmt5.setInt(1,withdraw);
			stmt5.setInt(2,accNo);
			int result5=stmt5.executeUpdate();
			if(result5>0)
			{
				PreparedStatement stmt33=conn.prepareStatement("insert into BankTransaction values(tranidseq.nextval,?,?,?,?,?)");
				stmt33.setInt(1,accNo);
				stmt33.setInt(2,accNo);
		    	stmt33.setInt(3,balance);
				stmt33.setInt(4,withdraw);
		    	stmt33.setString(5,"Withdraw");
		    	int result = stmt33.executeUpdate();
			}
			
		} 
		catch (SQLException e) {
			e.printStackTrace();
		}
        
		return withdraw;
	}

	@Override
	public int fundTransfer(int accNo, int accNo1, int amount) {
		int balance=0;
		int balance1=0;
		int minus = 0,add=0;
		try {
			PreparedStatement stmt6=conn.prepareStatement("select balance from BankInformation where accountno=?");
			stmt6.setInt(1,accNo);
			ResultSet result6=stmt6.executeQuery();
			result6.next();
			balance=result6.getInt(1);
			PreparedStatement stmt7=conn.prepareStatement("update BankInformation set balance=? where accountno=?");
			minus=balance-amount;
			stmt7.setInt(1,minus);
			stmt7.setInt(2,accNo);
			int result7=stmt7.executeUpdate();
			if(result7>0)
			{
				PreparedStatement stmt33=conn.prepareStatement("insert into BankTransaction values(tranidseq.nextval,?,?,?,?,?)");
				stmt33.setInt(1,accNo);
				stmt33.setInt(2,accNo);
		    	stmt33.setInt(3,balance);
				stmt33.setInt(4,minus);
		    	stmt33.setString(5,"Fund Transfer");
		    	int result33= stmt33.executeUpdate();
			}
			PreparedStatement stmt8=conn.prepareStatement("select balance from BankInformation where accountno=?");
			stmt8.setInt(1,accNo1);
			ResultSet result8=stmt8.executeQuery();
			result8.next();
			balance1=result8.getInt(1);
			PreparedStatement stmt9=conn.prepareStatement("update BankInformation set balance=? where accountno=?");
			add=balance1+amount;
			stmt9.setInt(1,add);
			stmt9.setInt(2,accNo1);
			int result9=stmt9.executeUpdate();
			if(result9>0)
			{
				PreparedStatement stmt33=conn.prepareStatement("insert into BankTransaction values(tranidseq.nextval,?,?,?,?,?)");
				stmt33.setInt(1,accNo1);
				stmt33.setInt(2,accNo1);
		    	stmt33.setInt(3,balance1);
				stmt33.setInt(4,add);
		    	stmt33.setString(5,"Fund Transfer");
		    	int result33 = stmt33.executeUpdate();
			}
		}
		catch (SQLException e) {
			e.printStackTrace();
		} 
		return minus;
	}

	@Override
	public void printTransaction() {
		BankTransaction bt=new BankTransaction();
		try {
			PreparedStatement stmt=conn.prepareStatement("select * from BankTransaction");
		    ResultSet result=stmt.executeQuery();
		    while(result.next())
		    {
		    	int tId=result.getInt(1);
		    	int fromAcc=result.getInt(2);
		        int toAcc=result.getInt(3);
		    	int oldBalance=result.getInt(4);
		    	int newBalance=result.getInt(5);
		    	String transType=result.getString(6);
		    	bt.settId(tId);
		    	bt.setFromAcc(fromAcc);
		    	bt.setToAcc(toAcc);
		    	bt.setOldBalance(oldBalance);
		    	bt.setNewBalance(newBalance);
		    	bt.setTransType(transType);
		    	System.out.println(bt);

		    }
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}

}
