package com.cap.dao;

import static org.junit.Assert.*;

import org.junit.Test;

public class BankDaoTest {
	BankDaoImpl dao=new BankDaoImpl();
	
	@Test
	public void test1(){
		int balance=1000;
		int result=balance+500;
		int expectedResult=1500;
		assertEquals(expectedResult,result);
		System.out.println(expectedResult=result);
	}
	
	@Test
	public void test2(){
		int balance2=1000;
		int result2=balance2+500;
		int expectedResult2=2500;
		assertEquals(expectedResult2,result2);
		System.out.println(expectedResult2=result2);
	}
	

}
