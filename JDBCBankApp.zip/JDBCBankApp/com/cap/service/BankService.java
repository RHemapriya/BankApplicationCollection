package com.cap.service;

import java.util.List;

import com.cap.bean.BankDetails;
import com.cap.bean.BankTransaction;

public interface BankService {
	int createBankAccount(BankDetails bankdetail);

	int showTheBalance(int accNo);

	int depositAmount(int accNo, int deposit);

	int withdrawAmount(int accNo, int withdraw);

	int fundTransfer(int accNo, int accNo1, int amount);

	void printTransaction();
	
	public boolean checkNameIsOk(String custName); //validate the customer name
	
	public boolean checkMobileNum(Long custMobile); //validate the mobile number

}
