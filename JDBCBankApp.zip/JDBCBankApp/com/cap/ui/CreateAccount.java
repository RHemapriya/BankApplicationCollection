package com.cap.ui;

import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.cap.bean.BankDetails;
import com.cap.bean.BankTransaction;
import com.cap.excep.AccountNotFoundException;
import com.cap.service.BankService;
import com.cap.service.BankServiceImpl;

public class CreateAccount {
	static BankService service = new BankServiceImpl();
	static BankDetails bankdetail = new BankDetails();
	static Scanner scan = new Scanner(System.in);

	public static void main(String[] args) {
//display the options in while loop
		while (true) {
			System.out.println("Welcome to this Bank!!!");
			
			System.out.println("1.Create Account");
			System.out.println("2.Show Balance");
			System.out.println("3.Deposit");
			System.out.println("4.Withdraw");
			System.out.println("5.Fund Transfer");
			System.out.println("6.Print Transactions");
			System.out.println("************************************************************");
			int option = scan.nextInt();
			switch (option) {
			
			case 1:
				
//Check the given name is valid or not
				
				String accName;
				boolean corrName;		
			do{
				System.out.println("Enter your name: ");
				accName=scan.next();
				corrName=service.checkNameIsOk(accName);
				if(!corrName)
				{
					System.out.println("Give only alphabetical letters");
				}	
			}while(!corrName);

//Check the given mobile number is valid or not
			
			long accMobileNo;			
			boolean corrMobile;
				do{
				System.out.println("Enter the Mobile number: ");
				accMobileNo = scan.nextLong();
				corrMobile=service.checkMobileNum(accMobileNo);
				if(!corrMobile)
				{
					System.out.println("Enter the valid mobile number");
				}
				}while(!corrMobile);
				
				System.out.println("Enter the Account Type: ");
				String accType = scan.next();
				System.out.println("Enter your branch: ");
				String accBranch = scan.next();
				System.out.println("Your balance is: ");
				int accBalance = scan.nextInt();
//set the details
				bankdetail.setAccName(accName);
				bankdetail.setAccMobileNo(accMobileNo);
				bankdetail.setAccType(accType);
				bankdetail.setAccBranch(accBranch);
				bankdetail.setAccBalance(accBalance);

				service.createBankAccount(bankdetail);
				System.out.println("Account created!!!!!!");
				System.out.println("Your account number is: "+bankdetail.getAccNo() );	
				break;

//show the balance		
			
			case 2:
				//Exception throw if account number is invalid
				try{
				System.out.println("Enter your Account number: ");
				int accNo1 = scan.nextInt();
				System.out.println("Your Balance is: " + service.showTheBalance(accNo1));
				}
				catch(AccountNotFoundException e){
					System.out.println("Enter valid account number");
					e.printStackTrace();
				}
				break;
				
//deposit the amount 

			case 3:
				//Exception throw if account number is invalid
				try{
				System.out.println("Enter your Account number:");
				int accNo2 = scan.nextInt();
				System.out.println("Enter the Amount: ");
				int deposit = scan.nextInt();
				bankdetail.setAccBalance(service.depositAmount(accNo2, deposit));
				System.out.println("Your current balance is " + bankdetail.getAccBalance());
				System.out.println("You deposited successfully!!!!!!!!!!!");
				}
				catch(AccountNotFoundException e){
					System.out.println("Enter valid account number");
					e.printStackTrace();
				}
				
				break;
				
//withdraw the amount 
				
			case 4:
				//Exception throw if account number is invalid
				try{
				System.out.println("Enter Your Account Number: ");
				int accNo3 = scan.nextInt();
				System.out.println("Enter the Amount:");
				int withdraw = scan.nextInt();
				bankdetail.setAccBalance(service.withdrawAmount(accNo3, withdraw));
				System.out.println("Your withdrawn amount is:" + bankdetail.getAccBalance());
				System.out.println("You Withdran successfully!!!!!!!!!!!");
				}
				catch(AccountNotFoundException e){
					System.out.println("Enter valid account number");
					e.printStackTrace();
				}
				
				break;

//transfer the amount 			
				
			case 5:
				//Exception throw if account number is invalid
				try{
				System.out.println("Fund transfer operation will made here!!!!!");
				System.out.println("Enter the my account number:");
				int accNo4 = scan.nextInt();
				System.out.println("Enter the transfer account number:");
				int accNo5 = scan.nextInt();
				System.out.println("Enter the Amount:");
				int amount = scan.nextInt();
				bankdetail.setAccBalance(service.fundTransfer(accNo4, accNo5, amount));
				System.out.println("Your withdrawn amount is:" + bankdetail.getAccBalance());
				}
				catch(AccountNotFoundException e){
					System.out.println("Enter valid account number");
					e.printStackTrace();
				}
				
				break;
				
//print the transaction 				

			case 6:
				System.out.println("Print the Transaction Details!!!!!!!!");
				service.printTransaction();
//				List<BankTransaction> bankTran = service.printTransaction();
//				Iterator<BankTransaction> itr = bankTran.iterator();
//				while (itr.hasNext()) {
//					System.out.println(itr.next());

				//}

			}

		}
	}
}
