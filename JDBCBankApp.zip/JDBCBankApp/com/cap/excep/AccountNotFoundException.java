package com.cap.excep;

public class AccountNotFoundException extends RuntimeException {
	
	public AccountNotFoundException(final String msg) {
		super(msg);
		
	}
	
	}
	


