package com.cap.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@Entity
@Table(name="BankTran")
@NamedQueries(@NamedQuery(name = "printTransaction", query = "SELECT bankTran FROM BankTransaction bankTran"))
public class BankTransaction {
	@Id
	@Column(name="tid",length=20)
	@GeneratedValue
	private int tId;
	@Column(name="fromAcc",length=20)
	private int fromAcc;
	@Column(name="toAcc",length=20)
	private int toAcc;
	@Column(name="oldBalance",length=20)
	private int oldBalance;
	@Column(name="newBalance",length=20)
	private int newBalance;
	@Column(name="transType",length=20)
	private String transType;

	
	public int gettId() {
		return tId;
	}


	public void settId(int tId) {
		this.tId = tId;
	}


	public int getFromAcc() {
		return fromAcc;
	}


	public void setFromAcc(int fromAcc) {
		this.fromAcc = fromAcc;
	}


	public int getToAcc() {
		return toAcc;
	}


	public void setToAcc(int toAcc) {
		this.toAcc = toAcc;
	}


	public int getOldBalance() {
		return oldBalance;
	}


	public void setOldBalance(int oldBalance) {
		this.oldBalance = oldBalance;
	}


	public int getNewBalance() {
		return newBalance;
	}


	public void setNewBalance(int newBalance) {
		this.newBalance = newBalance;
	}


	public String getTransType() {
		return transType;
	}


	public void setTransType(String transType) {
		this.transType = transType;
	}


	@Override
	public String toString() {
		return "BankTransaction [tId=" + tId + ", fromAcc=" + fromAcc + ", toAcc=" + toAcc + ", oldBalance="
				+ oldBalance + ", newBalance=" + newBalance + ", transType=" + transType + "]";
	}

}
