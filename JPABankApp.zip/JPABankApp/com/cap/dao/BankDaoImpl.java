package com.cap.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import com.cap.entities.BankDetails;
import com.cap.entities.BankTransaction;


public class BankDaoImpl implements BankDao {
	BankDetails bd=new BankDetails();
	BankTransaction tran=new BankTransaction();
	private EntityManager entityManager;

	public BankDaoImpl() {
		entityManager = JPAUtil.getEntityManager();
	}
	@Override
	public void createBankAccount(BankDetails bankdetail) {
		 entityManager.persist(bankdetail);
	}
	@Override
	public int showTheBalance(int accNo) {
		BankDetails show=entityManager.find(BankDetails.class, accNo);
		int bal=show.getAccBalance();
		return bal;
	}
	@Override
	public int depositAmount(int accNo, int deposit) {
		BankDetails show=entityManager.find(BankDetails.class, accNo);
		int bal=show.getAccBalance();
		int newBal=bal+deposit;
		show.setAccBalance(newBal);
		entityManager.merge(show);
		BankTransaction bk=new BankTransaction();
		bk.setFromAcc(accNo);
		bk.setToAcc(accNo);
		bk.setOldBalance(bal);
		bk.setNewBalance(newBal);
		bk.setTransType("Deposit");
		entityManager.persist(bk);
		return newBal;
	}
	@Override
	public int withdrawAmount(int accNo, int withdraw) {
		BankDetails show=entityManager.find(BankDetails.class, accNo);
		int bal=show.getAccBalance();
		int newBal=bal-withdraw;
		show.setAccBalance(newBal);
		entityManager.merge(show);
		BankTransaction bk=new BankTransaction();
		bk.setFromAcc(accNo);
		bk.setToAcc(accNo);
		bk.setOldBalance(bal);
		bk.setNewBalance(newBal);
		bk.setTransType("Withdraw");
		entityManager.persist(bk);
		return newBal;
	}
	@Override
	public int fundTransfer(int accNo, int accNo1, int amount) {
		BankDetails show=entityManager.find(BankDetails.class, accNo);
		int debit=show.getAccBalance();
		int debit1=debit-amount;
		show.setAccBalance(debit1);
		entityManager.merge(show);
		BankTransaction bk=new BankTransaction();
		bk.setFromAcc(accNo);
		bk.setToAcc(accNo1);
		bk.setOldBalance(debit);
		bk.setNewBalance(debit1);
		bk.setTransType("FundTransfer");
		entityManager.persist(bk);
		BankDetails show1=entityManager.find(BankDetails.class, accNo1);
		int credit=show1.getAccBalance();
		int credit1=credit+amount;
		show1.setAccBalance(credit1);
		entityManager.merge(show1);
		BankTransaction bk1=new BankTransaction();
		bk1.setFromAcc(accNo1);
		bk1.setToAcc(accNo);
		bk1.setOldBalance(credit);
		bk1.setNewBalance(credit1);
		bk1.setTransType("FundTransfer");
		entityManager.persist(bk1);
		return debit1;
	}
	@Override
	public List<BankTransaction> printTransaction() {
		Query query = entityManager.createNamedQuery("printTransaction");
		List<BankTransaction> tran = query.getResultList();
		return tran;
		
		
	}
	@Override
	public void beginTransaction() {
		entityManager.getTransaction().begin();
		
	}
	@Override
	public void commitTransaction() {
		entityManager.getTransaction().commit();
		
		
	}
	
	

}
