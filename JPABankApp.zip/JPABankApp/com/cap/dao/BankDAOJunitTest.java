package com.cap.dao;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotSame;

import org.junit.Test;

public class BankDAOJunitTest {
BankDaoImpl dao=new BankDaoImpl();
	
	@Test
	public void test1(){
		int deposit=1000;
		int oldBal=dao.showTheBalance(7);
		int result=dao.depositAmount(7, deposit);
		int expectedResult=oldBal+deposit;
		assertEquals(expectedResult,result);
		System.out.println(expectedResult=result);
	}
	
	@Test
	public void test2(){
		int withdraw=2000;
		int oldBal=dao.showTheBalance(7);
		int result=dao.withdrawAmount(7, withdraw);
		int expectedResult=oldBal-withdraw;
		assertNotSame(result,expectedResult);
		System.out.println(expectedResult=result);
	}

}

