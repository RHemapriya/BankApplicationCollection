package com.cap.service;

import java.util.List;

import com.cap.dao.BankDao;
import com.cap.dao.BankDaoImpl;
import com.cap.entities.BankDetails;
import com.cap.entities.BankTransaction;

public class BankServiceImpl implements BankService {
	private BankDao dao;

	public BankServiceImpl() {
		dao = new BankDaoImpl();
	}

	@Override // create the bank account using createBankAccount method
	public void createBankAccount(BankDetails bankdetail) {
		dao.beginTransaction();
		dao.createBankAccount(bankdetail);
		dao.commitTransaction();
	}

	@Override // showing the balance using showTheBalance method
	public int showTheBalance(int accNo) {
		dao.beginTransaction();
		int accBalance = dao.showTheBalance(accNo);
		dao.commitTransaction();
		return accBalance;
	}

	// deposit the amount using depositAmount method
	public int depositAmount(int accNo, int deposit) {
		dao.beginTransaction();
		int prev = dao.showTheBalance(accNo);
		int current = prev + deposit;
		dao.depositAmount(accNo, deposit);
		dao.commitTransaction();
		return current;
	}

	@Override // withdraw the amount using the withdrawAmount method
	public int withdrawAmount(int accNo, int withdraw) {
		dao.beginTransaction();
		int bal = dao.showTheBalance(accNo);
		int currBal = bal - withdraw;
		dao.withdrawAmount(accNo, withdraw);
		dao.commitTransaction();
		return currBal;
	}

	@Override // transfer the fund using fundTransfer method
	public int fundTransfer(int accNo, int accNo1, int amount) {
		dao.beginTransaction();
		int from = dao.showTheBalance(accNo);
		int minus = from - amount;
		int to = dao.showTheBalance(accNo1);
		int add = to + amount;
		int updateFromBal = dao.fundTransfer(accNo, accNo1, amount);
		dao.commitTransaction();
		return minus;
	}

	@Override // using list for print the transaction
	public List<BankTransaction> printTransaction() {
		 dao.beginTransaction();
		 List<BankTransaction> l=dao.printTransaction();
		 dao.commitTransaction();
	     return l;
	}

	@Override // validate the name
	public boolean checkNameIsOk(String custName) {
		if (custName.matches("[A-Z][a-zA-Z]*")) {
			return true;
		} else {
			return false;
		}
	}

	@Override // validate the mobile number
	public boolean checkMobileNum(Long custMobile) {
		String mno = Long.toString(custMobile);
		if (mno.matches("[7-9][0-9]{9}")) {
			return true;
		} else {
			return false;
		}
	}

}
