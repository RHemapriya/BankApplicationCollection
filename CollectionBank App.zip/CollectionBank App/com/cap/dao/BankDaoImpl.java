package com.cap.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.cap.bean.BankDetails;
import com.cap.bean.BankTransaction;
import com.cap.excep.AccountNotFoundException;

public class BankDaoImpl implements BankDao {

	Map<Integer, BankDetails> details = new HashMap<Integer, BankDetails>();  //create map for store the details using 'details' object
	Map<BankTransaction, Integer> trans = new HashMap<BankTransaction, Integer>(); //transaction details stored here

	@Override//put the bank detail in details object
	public BankDetails createBankAccount(BankDetails bankdetail) {
		return details.put(bankdetail.getAccNo(), bankdetail);
	}

	public int showTheBalance(int accNo){
		details.get(accNo);	
		int accBalance = 0;
		
		//check the condition, if it is right show the balance otherwise throw the exception
		if(details.get(accNo)==null)
		{
		throw new AccountNotFoundException("Your Account number is wrong");
		}
		else
		{
			accBalance = details.get(accNo).getAccBalance();
		}
		return accBalance;
	}

//check the condition, account number is correct amount deposited otherwise throw the exception
	public int depositAmount(int accNo, int deposit) {
		int updateDeposit=details.get(accNo).getAccBalance()+deposit;
		if(details.get(accNo)==null)
		{
		throw new AccountNotFoundException("Your Account number is wrong");
		}
		else
		{
		deposit = details.get(accNo).getAccBalance();
		}
		
		BankTransaction bankTran = new BankTransaction();
		bankTran.settId(1234);
		bankTran.setFromAcc(accNo);
		bankTran.setToAcc(accNo);
		bankTran.setOldBalance(details.get(accNo).getAccBalance());
		bankTran.setNewBalance(updateDeposit);
		bankTran.setTransType("Deposit");
		trans.put(bankTran, accNo);
		return deposit;
	}

	@Override//check the condition, account number is correct amount withdraw otherwise throw the exception
	public int withdrawAmount(int accNo, int withdraw) {
		int updateWithdraw=details.get(accNo).getAccBalance()-withdraw;
		
		if(details.get(accNo)==null)
		{
		throw new AccountNotFoundException("Your Account number is wrong");
		}
		else
		{
		withdraw = details.get(accNo).getAccBalance();
		}
		
		BankTransaction bankTran = new BankTransaction();
		bankTran.settId(1234);
		bankTran.setFromAcc(accNo);
		bankTran.setToAcc(accNo);
		bankTran.setOldBalance(details.get(accNo).getAccBalance());
		bankTran.setNewBalance(updateWithdraw);
		bankTran.setTransType("Withdraw");
		trans.put(bankTran, accNo);
		return withdraw;
	}

	@Override
	public int fundTransfer(int accNo, int accNo1, int amount) {
		int fromBal;
		int toBal;
		int updateFromBal;
		int updateToBal;
//check account number if it is right transfer the amount otherwise throw the exception
		if(details.get(accNo)==null)
		{
		throw new AccountNotFoundException("Your Account number is wrong");
		}
		else
		{
		fromBal = details.get(accNo).getAccBalance();
		toBal = details.get(accNo1).getAccBalance();
		updateFromBal=fromBal-amount;
		updateToBal=toBal+amount;
		}
		BankTransaction bankTran = new BankTransaction();
		bankTran.settId(1234);
		bankTran.setFromAcc(accNo);
		bankTran.setToAcc(accNo1);
		bankTran.setOldBalance(details.get(accNo).getAccBalance());
		bankTran.setNewBalance(updateFromBal);
		bankTran.setTransType("Fund Transfer");
		trans.put(bankTran, accNo);
		return updateFromBal;	
	}
//using list for transaction
	public List<BankTransaction> printTransaction() {
		System.out.println("**********************" + trans.size());
		List<BankTransaction> list = new ArrayList<BankTransaction>(trans.keySet());//change the map as set in list
		return list;
	}

}
