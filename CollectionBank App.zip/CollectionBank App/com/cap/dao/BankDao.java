package com.cap.dao;

import java.util.List;

import com.cap.bean.BankDetails;
import com.cap.bean.BankTransaction;

public interface BankDao {
	BankDetails createBankAccount(BankDetails bankdetail);
	
	int showTheBalance(int accNo);

	int depositAmount(int accNo, int deposit);
	
	int withdrawAmount(int accNo,int withdraw);
	
	int fundTransfer(int accNo,int accNo1,int amount);
	
	List<BankTransaction> printTransaction();

}
