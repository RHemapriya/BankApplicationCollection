package com.cap.service;

import java.util.List;

import com.cap.bean.BankDetails;
import com.cap.bean.BankTransaction;
import com.cap.dao.BankDao;
import com.cap.dao.BankDaoImpl;

public class BankServiceImpl implements BankService {
	BankDao dao = new BankDaoImpl();  //creating dao object

	@Override //create the bank account using createBankAccount method
	public BankDetails createBankAccount(BankDetails bankdetail) {
		return dao.createBankAccount(bankdetail);
	}

	@Override//showing the balance using showTheBalance method
	public int showTheBalance(int accNo) {
		int accBalance = dao.showTheBalance(accNo);
		return accBalance;
	}

	//deposit the amount using depositAmount method
	public int depositAmount(int accNo, int deposit) {
		int prev = dao.showTheBalance(accNo);
		int current = prev + deposit;
		dao.depositAmount(accNo, deposit);
		return current;
	}

	@Override//withdraw the amount using the withdrawAmount method
	public int withdrawAmount(int accNo, int withdraw) {
		int bal = dao.showTheBalance(accNo);
		int currBal = bal - withdraw;
		dao.withdrawAmount(accNo, withdraw);
		return currBal;
	}

	@Override//transfer the fund using fundTransfer method
	public int fundTransfer(int accNo, int accNo1, int amount) {
		int from = dao.showTheBalance(accNo);
		int minus = from - amount;
		int to = dao.showTheBalance(accNo1);
		int add = to + amount;
		int updateFromBal = dao.fundTransfer(accNo, accNo1, amount);
		return minus;
	}

	@Override//using list for print the transaction
	public List<BankTransaction> printTransaction() {
		return dao.printTransaction();
	}

	@Override//validate the name 
	public boolean checkNameIsOk(String custName) {
		if (custName.matches("[A-Z][a-zA-Z]*")) {
			return true;
		} else {
			return false;
		}
	}

	@Override//validate the mobile number
	public boolean checkMobileNum(Long custMobile) {
		String mno = Long.toString(custMobile);
		if (mno.matches("[7-9][0-9]{9}")) {
			return true;
		} else {
			return false;
		}
	}

}
