package com.cap.bean;

public class BankDetails {
	private int accNo;
	private String accName;
	private long accMobileNo;
	private String accType;
	private String accBranch;
	private int accBalance;
	
	public int getAccNo() {
		 accNo=(int) (accMobileNo+1000);
		return accNo;
	}
	public void setAccNo(int accNo) {
		this.accNo = accNo;
	}
	public String getAccName() {
		return accName;
	}
	public void setAccName(String accName) {
		this.accName = accName;
	}
	public long getAccMobileNo() {
		return accMobileNo;
	}
	public void setAccMobileNo(long accMobileNo) {
		this.accMobileNo = accMobileNo;
	}
	public String getAccType() {
		return accType;
	}
	public void setAccType(String accType) {
		this.accType = accType;
	}
	public String getAccBranch() {
		return accBranch;
	}
	public void setAccBranch(String accBranch) {
		this.accBranch = accBranch;
	}
	public int getAccBalance() {
		return accBalance;
		
	}
	public void setAccBalance(int accBalance) {
		this.accBalance = accBalance;
	}

	
	@Override
	public String toString() {
		return "BankDetails [accNo=" + accNo + ", accName=" + accName + ", accMobileNo=" + accMobileNo + ", accType="
				+ accType + ", accBranch=" + accBranch + ", accBalance=" + accBalance + "]";
	}
	
	
	
}
