package com.cap.bean;

public class BankTransaction {
	private int tId;
	private int fromAcc;
	private int toAcc;
	private int oldBalance;
	private int newBalance;
	private String transType;

	
	public int gettId() {
		return tId;
	}


	public void settId(int tId) {
		this.tId = tId;
	}


	public int getFromAcc() {
		return fromAcc;
	}


	public void setFromAcc(int fromAcc) {
		this.fromAcc = fromAcc;
	}


	public int getToAcc() {
		return toAcc;
	}


	public void setToAcc(int toAcc) {
		this.toAcc = toAcc;
	}


	public int getOldBalance() {
		return oldBalance;
	}


	public void setOldBalance(int oldBalance) {
		this.oldBalance = oldBalance;
	}


	public int getNewBalance() {
		return newBalance;
	}


	public void setNewBalance(int newBalance) {
		this.newBalance = newBalance;
	}


	public String getTransType() {
		return transType;
	}


	public void setTransType(String transType) {
		this.transType = transType;
	}


	@Override
	public String toString() {
		return "BankTransaction [tId=" + tId + ", fromAcc=" + fromAcc + ", toAcc=" + toAcc + ", oldBalance="
				+ oldBalance + ", newBalance=" + newBalance + ", transType=" + transType + "]";
	}

}
